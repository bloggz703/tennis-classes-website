# Tennis Classes Near Me Website

A comprehensive web platform to help users find local tennis classes through an interactive, geographically-aware search interface.

## Features

- Location-based tennis class search
- Interactive map integration
- Responsive design
- Advanced filtering options
- SEO optimized
- Mobile-friendly interface

## Technologies Used

- HTML5
- CSS3 (Bootstrap 5.3.0)
- JavaScript
- Google Maps API
- OpenCage Geocoding API

## Setup

1. Clone the repository
2. No build process required - static HTML site
3. Open index.html in a browser

## Local Development

Run a local server:
```bash
python -m http.server 8000
```

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## License

MIT License - see LICENSE file for details
