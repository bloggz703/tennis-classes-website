const CACHE_NAME = 'tennis-classes-v1';
const DYNAMIC_CACHE = 'tennis-classes-dynamic-v1';
const OFFLINE_DB_NAME = 'tennis-classes-offline';
const OFFLINE_STORE_NAME = 'places';
const SYNC_QUEUE_NAME = 'favorites-sync';

const urlsToCache = [
  '/',
  '/index.html',
  '/css/style.css',
  '/js/main.js',
  '/images/logo.png',
  '/images/hero-banner.jpg',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css'
];

// Open IndexedDB
function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(OFFLINE_DB_NAME, 1);
        
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(OFFLINE_STORE_NAME)) {
                db.createObjectStore(OFFLINE_STORE_NAME, { keyPath: 'place_id' });
            }
        };
    });
}

// Store place data in IndexedDB
async function storePlaceData(place) {
    const db = await openDB();
    const tx = db.transaction(OFFLINE_STORE_NAME, 'readwrite');
    const store = tx.objectStore(OFFLINE_STORE_NAME);
    await store.put(place);
}

// Retrieve place data from IndexedDB
async function getPlaceData(placeId) {
    const db = await openDB();
    const tx = db.transaction(OFFLINE_STORE_NAME, 'readonly');
    const store = tx.objectStore(OFFLINE_STORE_NAME);
    return store.get(placeId);
}

// Install service worker
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(urlsToCache))
            .then(() => self.skipWaiting())
    );
});

// Activate and clean up old caches
self.addEventListener('activate', event => {
    event.waitUntil(
        Promise.all([
            caches.keys().then(keys => {
                return Promise.all(
                    keys.filter(key => key !== CACHE_NAME && key !== DYNAMIC_CACHE)
                        .map(key => caches.delete(key))
                );
            }),
            self.clients.claim()
        ])
    );
});

// Handle fetch requests
self.addEventListener('fetch', event => {
    // Skip non-GET requests and cross-origin requests
    if (event.request.method !== 'GET' || 
        !event.request.url.startsWith(self.location.origin) &&
        !event.request.url.startsWith('https://cdn.jsdelivr.net') &&
        !event.request.url.startsWith('https://cdnjs.cloudflare.com')) {
        return;
    }

    // Handle API requests
    if (event.request.url.includes('api.opencagedata.com') || 
        event.request.url.includes('maps.googleapis.com')) {
        event.respondWith(
            fetch(event.request)
                .then(response => {
                    // Clone the response
                    const responseToCache = response.clone();
                    
                    // Cache the response
                    caches.open(DYNAMIC_CACHE).then(cache => {
                        cache.put(event.request, responseToCache);
                    });
                    
                    return response;
                })
                .catch(async () => {
                    // Try to get from cache
                    const cachedResponse = await caches.match(event.request);
                    if (cachedResponse) {
                        return cachedResponse;
                    }
                    
                    // Return offline response
                    return new Response(
                        JSON.stringify({ 
                            error: 'You are offline. Please check your connection.' 
                        }),
                        { 
                            headers: { 'Content-Type': 'application/json' },
                            status: 503,
                            statusText: 'Service Unavailable'
                        }
                    );
                })
        );
        return;
    }

    event.respondWith(
        caches.match(event.request)
            .then(response => {
                if (response) {
                    return response;
                }
                return fetch(event.request)
                    .then(response => {
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }
                        const responseToCache = response.clone();
                        caches.open(CACHE_NAME)
                            .then(cache => {
                                cache.put(event.request, responseToCache);
                            });
                        return response;
                    });
            })
    );
});

// Handle background sync for favorites
self.addEventListener('sync', event => {
    if (event.tag === SYNC_QUEUE_NAME) {
        event.waitUntil(
            syncFavorites()
        );
    }
});

// Sync favorites with server when online
async function syncFavorites() {
    try {
        const db = await openDB();
        const tx = db.transaction(OFFLINE_STORE_NAME, 'readonly');
        const store = tx.objectStore(OFFLINE_STORE_NAME);
        const pendingFavorites = await store.getAll();
        
        // Process each pending favorite
        const syncPromises = pendingFavorites.map(async favorite => {
            try {
                // Attempt to sync with server
                const response = await fetch('/api/favorites', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(favorite)
                });
                
                if (response.ok) {
                    // Remove from pending queue
                    const tx = db.transaction(OFFLINE_STORE_NAME, 'readwrite');
                    const store = tx.objectStore(OFFLINE_STORE_NAME);
                    await store.delete(favorite.place_id);
                }
            } catch (error) {
                console.error('Error syncing favorite:', error);
            }
        });
        
        await Promise.all(syncPromises);
    } catch (error) {
        console.error('Error in syncFavorites:', error);
        throw error;
    }
}

// Handle push notifications
self.addEventListener('push', event => {
    const options = {
        body: event.data.text(),
        icon: '/images/icon-192x192.png',
        badge: '/images/icon-192x192.png',
        vibrate: [100, 50, 100],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        },
        actions: [
            {
                action: 'explore',
                title: 'View Details'
            },
            {
                action: 'close',
                title: 'Close'
            }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification('Tennis Classes Near Me', options)
    );
});
